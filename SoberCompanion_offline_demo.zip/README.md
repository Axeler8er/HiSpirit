# SoberCompanion (offline demo APK via GitHub Actions)

**Что это?** Минимальный офлайновый «муляж» eHealth‑приложения с Jetpack Compose: главная, дневник настроения (4 ползунка), знания/навыки, SOS. Никакого сервера; данные — локально через DataStore.

## Как собрать APK без Android Studio
1. Создайте пустой репозиторий на GitHub и загрузите сюда все файлы проекта.
2. Откройте вкладку **Actions** → согласитесь включить GitHub Actions.
3. Запустите workflow **Android CI (assemble debug)** (кнопка *Run workflow*), либо просто сделайте push в `main`.
4. По завершении сборки перейдите в шаг **Upload APK** и скачайте артефакт `app-debug.apk`.

## Что внутри
- Jetpack Compose / Material 3 / Navigation
- Экраны: Home, Mood Diary (4 слайдера), Education (памятки), SOS (звонки/план безопасности)
- Мини‑иллюстрация маскота, рисуемая векторно (без внешних ресурсов)
- Пастельная «скандинавская» палитра

## Локальный запуск (опционально)
Если у вас всё‑таки есть Gradle/SDK, запустите:  
```bash
./gradlew :app:assembleDebug
```
APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

---

**Важно:** Это демонстрационный проект без сетевых разрешений и без передачи данных.