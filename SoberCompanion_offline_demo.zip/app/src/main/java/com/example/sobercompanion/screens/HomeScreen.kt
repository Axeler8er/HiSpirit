package com.example.sobercompanion.screens

    import androidx.compose.foundation.layout.*
    import androidx.compose.material3.*
    import androidx.compose.runtime.Composable
    import androidx.compose.ui.Alignment
    import androidx.compose.ui.Modifier
    import androidx.compose.ui.text.font.FontWeight
    import androidx.compose.ui.unit.dp
    import androidx.navigation.NavController
    import com.example.sobercompanion.NurseMascot
    import com.example.sobercompanion.navigation.Dest

    @Composable
    fun HomeScreen(nav: NavController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                NurseMascot(Modifier.size(72.dp))
                Column {
                    Text("Рада видеть вас", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Давайте бережно позаботимся о себе сегодня.", style = MaterialTheme.typography.bodyMedium)
                }
            }

            ElevatedCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Сегодня", style = MaterialTheme.typography.titleMedium)
                    Text("• Отметить настроение
• Сделать дыхательную практику (2 мин)
• Проверить напоминания", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { nav.navigate(Dest.Mood.name) }) { Text("Дневник настроения") }
                        OutlinedButton(onClick = { nav.navigate(Dest.Education.name) }) { Text("Навыки") }
                    }
                }
            }

            ElevatedCard {
                Column(Modifier.padding(16.dp)) {
                    Text("Если нужен быстрый контакт", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { nav.navigate(Dest.SOS.name) }, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Открыть SOS")
                    }
                }
            }
        }
    }