package com.example.sobercompanion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Sos
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.sobercompanion.navigation.AppNavGraph
import com.example.sobercompanion.navigation.Dest
import com.example.sobercompanion.ui.theme.SoberTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route

    SoberTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = current == Dest.Home.name,
                        onClick = { nav.navigate(Dest.Home.name) { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Главная") },
                        label = { Text("Главная") }
                    )
                    NavigationBarItem(
                        selected = current == Dest.Mood.name,
                        onClick = { nav.navigate(Dest.Mood.name) { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Favorite, contentDescription = "Настроение") },
                        label = { Text("Настроение") }
                    )
                    NavigationBarItem(
                        selected = current == Dest.Education.name,
                        onClick = { nav.navigate(Dest.Education.name) { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.MenuBook, contentDescription = "Знания") },
                        label = { Text("Знания") }
                    )
                    NavigationBarItem(
                        selected = current == Dest.SOS.name,
                        onClick = { nav.navigate(Dest.SOS.name) { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Sos, contentDescription = "SOS") },
                        label = { Text("SOS") }
                    )
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner)) {
                AppNavGraph(nav)
            }
        }
    }
}