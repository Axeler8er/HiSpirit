package com.example.sobercompanion.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.sobercompanion.screens.*

enum class Dest { Home, Mood, Education, SOS, Settings }

@Composable
fun AppNavGraph(nav: NavHostController) {
    NavHost(navController = nav, startDestination = Dest.Home.name) {
        composable(Dest.Home.name) { HomeScreen(nav) }
        composable(Dest.Mood.name) { MoodDiaryScreen(nav) }
        composable(Dest.Education.name) { EducationScreen(nav) }
        composable(Dest.SOS.name) { SOSScreen(nav) }
        composable(Dest.Settings.name) { SettingsScreen() }
    }
}