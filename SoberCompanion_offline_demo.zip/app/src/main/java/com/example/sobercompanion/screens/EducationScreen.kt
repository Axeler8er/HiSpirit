package com.example.sobercompanion.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private val topics = listOf(
    "Признаки передозировки и первые действия",
    "Налоксон: носить, хранить, применять",
    "Дыхательные практики на 2 минуты",
    "Сон и стресс: базовые правила",
    "План безопасности на выходные"
)

@Composable
fun EducationScreen(nav: NavController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Знания и навыки", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(topics) { t ->
                ElevatedCard {
                    Column(Modifier.padding(16.dp)) {
                        Text(t, style = MaterialTheme.typography.titleMedium)
                        Text("Короткая памятка в 1–2 минуты чтения.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { /* open detail stub */ }) { Text("Открыть") }
                    }
                }
            }
        }
    }
}