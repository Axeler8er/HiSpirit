package com.example.sobercompanion.screens

    import android.content.Intent
    import android.net.Uri
    import androidx.compose.foundation.layout.*
    import androidx.compose.material3.*
    import androidx.compose.runtime.Composable
    import androidx.compose.ui.Modifier
    import androidx.compose.ui.unit.dp
    import androidx.compose.ui.platform.LocalContext
    import androidx.navigation.NavController

    @Composable
    fun SOSScreen(nav: NavController) {
        val ctx = LocalContext.current
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Экстренная помощь", style = MaterialTheme.typography.titleLarge)
            Text("Выберите действие — приложение не передаёт данные без вашего согласия.", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = {
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))
                ctx.startActivity(i)
            }, modifier = Modifier.fillMaxWidth()) { Text("Позвонить 112") }
            OutlinedButton(onClick = {
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:88002000000"))
                ctx.startActivity(i)
            }, modifier = Modifier.fillMaxWidth()) { Text("Горячая линия (пример)") }
            ElevatedCard {
                Column(Modifier.padding(16.dp)) {
                    Text("План безопасности", style = MaterialTheme.typography.titleMedium)
                    Text("1) Перейдите в безопасное место
2) Позвоните доверенному человеку
3) Дышите по схеме 4‑4‑4‑4
4) Используйте план отвлечения (музыка, прогулка, душ)")
                }
            }
        }
    }