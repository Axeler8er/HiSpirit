package com.example.sobercompanion

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.dp

/**
 * Minimal, abstract cartoon nurse illustration (soft tones) purely in vector drawing,
 * so the project has no external image dependencies.
 */
@Composable
fun NurseMascot(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        // Hair (light blond, not white)
        drawCircle(color = Color(0xFFF2E7C9), radius = w * 0.28f, center = Offset(w*0.5f, h*0.28f))
        // Face (pale skin)
        drawCircle(color = Color(0xFFF6EDE5), radius = w * 0.22f, center = Offset(w*0.5f, h*0.32f))
        // Eyes
        drawCircle(color = Color(0xFF8FBFE3), radius = w*0.02f, center = Offset(w*0.45f, h*0.32f))
        drawCircle(color = Color(0xFF8FBFE3), radius = w*0.02f, center = Offset(w*0.55f, h*0.32f))
        // Nurse cap
        drawRoundRect(
            color = Color(0xFFF0F4F8),
            topLeft = Offset(w*0.35f, h*0.13f),
            size = androidx.compose.ui.geometry.Size(w*0.3f, h*0.07f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w*0.02f, w*0.02f)
        )
        // Body dress (blue with white apron)
        drawRoundRect(
            color = Color(0xFFB4C6E5),
            topLeft = Offset(w*0.32f, h*0.46f),
            size = androidx.compose.ui.geometry.Size(w*0.36f, h*0.42f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w*0.08f, w*0.08f)
        )
        drawRoundRect(
            color = Color(0xFFF3F6FA),
            topLeft = Offset(w*0.37f, h*0.52f),
            size = androidx.compose.ui.geometry.Size(w*0.26f, h*0.28f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w*0.04f, w*0.04f)
        )
    }
}