package com.example.sobercompanion.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Scandinavian soft palette
val Sand = Color(0xFFF1EDE7)
val Mist = Color(0xFFE7EEF1)
val Sage = Color(0xFFDCE8E1)
val Blush = Color(0xFFF3E6E8)
val Steel = Color(0xFF5B6670)
val Ink = Color(0xFF2C2F33)

private val LightColors = lightColorScheme(
    primary = Steel,
    onPrimary = Color.White,
    secondary = Sage,
    onSecondary = Ink,
    background = Sand,
    onBackground = Ink,
    surface = Mist,
    onSurface = Ink
)

@Composable
fun SoberTheme(content: @Composable () -> Unit) {
    val scheme = LightColors
    MaterialTheme(
        colorScheme = scheme,
        typography = Typography(),
        content = content
    )
}