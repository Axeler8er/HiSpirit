package com.example.sobercompanion.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "mood")

object MoodKeys {
    val mood = intPreferencesKey("mood")
    val craving = intPreferencesKey("craving")
    val stress = intPreferencesKey("stress")
    val energy = intPreferencesKey("energy")
}

class MoodRepo(private val context: Context) {
    val state: Flow<Map<String, Int>> = context.dataStore.data.map { prefs ->
        mapOf(
            "mood" to (prefs[MoodKeys.mood] ?: 5),
            "craving" to (prefs[MoodKeys.craving] ?: 3),
            "stress" to (prefs[MoodKeys.stress] ?: 4),
            "energy" to (prefs[MoodKeys.energy] ?: 5),
        )
    }

    suspend fun save(m: Int, c: Int, s: Int, e: Int) {
        context.dataStore.edit { prefs ->
            prefs[MoodKeys.mood] = m
            prefs[MoodKeys.craving] = c
            prefs[MoodKeys.stress] = s
            prefs[MoodKeys.energy] = e
        }
    }
}