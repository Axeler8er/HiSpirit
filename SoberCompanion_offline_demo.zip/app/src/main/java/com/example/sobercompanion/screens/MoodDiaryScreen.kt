package com.example.sobercompanion.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.sobercompanion.NurseMascot
import com.example.sobercompanion.data.MoodRepo
import kotlinx.coroutines.launch

@Composable
fun MoodDiaryScreen(nav: NavController) {
    val ctx = LocalContext.current
    val repo = remember { MoodRepo(ctx) }
    val scope = rememberCoroutineScope()

    var mood by remember { mutableStateOf(5f) }
    var craving by remember { mutableStateOf(3f) }
    var stress by remember { mutableStateOf(4f) }
    var energy by remember { mutableStateOf(5f) }

    // load existing
    val state by repo.state.collectAsState(initial = emptyMap())
    LaunchedEffect(state) {
        state["mood"]?.let { mood = it.toFloat() }
        state["craving"]?.let { craving = it.toFloat() }
        state["stress"]?.let { stress = it.toFloat() }
        state["energy"]?.let { energy = it.toFloat() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.weight(1f)) {
                Text("Дневник настроения", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("Я чувствую себя…", style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = { /* open trends (stub) */ }) {
                Icon(Icons.Default.ShowChart, contentDescription = "Посмотреть динамику")
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            NurseMascot(Modifier.size(64.dp))
            Spacer(Modifier.width(12.dp))
            Text("Отметьте ваше состояние с помощью ползунков — это займёт меньше минуты.", style = MaterialTheme.typography.bodyMedium)
        }

        // Four sliders with emoji-like labels
        SliderRow(title = "Настроение", value = mood, onChange = { mood = it }, left = "😞", right = "😊")
        SliderRow(title = "Тяга", value = craving, onChange = { craving = it }, left = "🧘", right = "🔥")
        SliderRow(title = "Стресс", value = stress, onChange = { stress = it }, left = "😌", right = "😣")
        SliderRow(title = "Энергия", value = energy, onChange = { energy = it }, left = "🥱", right = "⚡")

        Button(
            onClick = {
                scope.launch { repo.save(mood.toInt(), craving.toInt(), stress.toInt(), energy.toInt()) }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Сохранить")
        }
    }
}

@Composable
private fun SliderRow(
    title: String,
    value: Float,
    onChange: (Float) -> Unit,
    left: String,
    right: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text("${value.toInt()}/10", style = MaterialTheme.typography.bodyMedium)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(left)
            Slider(
                value = value,
                onValueChange = onChange,
                steps = 8,
                valueRange = 1f..10f,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text(right)
        }
        Divider()
    }
}