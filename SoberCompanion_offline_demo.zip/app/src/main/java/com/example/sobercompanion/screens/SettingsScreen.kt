package com.example.sobercompanion.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Настройки", style = MaterialTheme.typography.titleLarge)
        Text("Это демонстрационный офлайновый муляж. Данные хранятся локально.")
        Divider()
        Text("Конфиденциальность", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Собирать анонимные агрегаты (демо)")
            Switch(checked = false, onCheckedChange = {})
        }
    }
}